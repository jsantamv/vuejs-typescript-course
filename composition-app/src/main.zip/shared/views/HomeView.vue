<script setup lang="ts"></script>

<template>
  <main>
    <h1>HOME HOME</h1>
  </main>
</template>
