export type { PokemonListResponse } from './pokemons-list.response';
export type { PokemonResponse } from './pokemon.response';
export type { Pokemon } from './pokemon';