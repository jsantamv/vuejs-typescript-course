<script setup lang="ts">
</script>

<template>
  <div>
    <h1>Pokemon Search</h1>
  </div>
</template>
