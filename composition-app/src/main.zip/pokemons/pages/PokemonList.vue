<script setup lang="ts">
import { useQuery } from "@tanstack/vue-query";
import { getPokemons } from "../helpers/get-pokemons";
import { computed } from "vue";

// import { usePokemons } from '../composables/usePokemons';
// const { count, pokemons, isLoading } = usePokemons()

const { isLoading, data: pokemons } = useQuery(
  ["pokemons"],
  getPokemons
  // Aquí faltaba una coma al final de la llamada a getPokemons
);

// Agrega verificación si 'pokemons' está definido antes de usar 'pokemons.value'
const count = computed(() => pokemons?.value?.length ?? 0); // Usa el operador de encadenamiento opcional y el operador de coalescencia nula para evitar errores si 'pokemons' es undefined o null.
</script>

<template>
  <div>
    <h1>Pokemon List - ({{ count }})</h1>

    <h3 v-if="isLoading">Cargando</h3>

    <ul>
      <li v-for="pokemon in pokemons" :key="pokemon.id">
        {{ pokemon.name }}
      </li>
    </ul>
  </div>
</template>
