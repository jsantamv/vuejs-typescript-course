<script setup lang="ts"></script>

<template>
  <div>
    <h1>Pokemon By ID</h1>
  </div>
</template>
